# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry_project']

package_data = \
{'': ['*']}

install_requires = \
['pytest>=7.1,<8.0', 'selene==2.0.0b12']

setup_kwargs = {
    'name': 'poetry-project',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'vlad',
    'author_email': 'khalvlalove@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
